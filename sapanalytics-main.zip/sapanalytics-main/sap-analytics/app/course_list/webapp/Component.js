sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("courselist.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);