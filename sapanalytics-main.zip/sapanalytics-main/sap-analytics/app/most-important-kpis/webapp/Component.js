sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("mik.mostimportantkpis.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);