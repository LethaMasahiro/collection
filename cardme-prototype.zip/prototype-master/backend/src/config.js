const port  = 3001
const mongoURI = "mongodb+srv://cmUser:ZTPcEklg2edpLucc@cardme-db.1hgdco1.mongodb.net/?retryWrites=true&w=majority"
const jwtSecret = "secret secretion here"

module.exports = {
    port,
    mongoURI,
    jwtSecret,
};